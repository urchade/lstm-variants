# Original-LSTM

Implementation of the original LSTM (without forget gate) (Hochreiter and Schmidhuber, 1997)

The paper: https://www.mitpressjournals.org/doi/10.1162/neco.1997.9.8.1735
